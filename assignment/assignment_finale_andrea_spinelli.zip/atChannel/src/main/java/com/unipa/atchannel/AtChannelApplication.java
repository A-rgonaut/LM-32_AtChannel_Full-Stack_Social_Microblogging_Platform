package com.unipa.atchannel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtChannelApplication {

    public static void main(String[] args) {
        SpringApplication.run(AtChannelApplication.class, args);
    }

}
