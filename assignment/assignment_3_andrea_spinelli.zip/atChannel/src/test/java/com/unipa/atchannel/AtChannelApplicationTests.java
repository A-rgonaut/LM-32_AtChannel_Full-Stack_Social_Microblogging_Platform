package com.unipa.atchannel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtChannelApplicationTests {

    @Test
    void contextLoads() {
    }

}
